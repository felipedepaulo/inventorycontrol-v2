package com.anydigital.inventorycontrolv1

import android.content.Intent
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.cardview.widget.CardView
import com.anydigital.inventorycontrolv1.util.Util
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase


class MainActivity : AppCompatActivity(), View.OnClickListener{
    private lateinit var auth: FirebaseAuth;


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)
        auth = Firebase.auth

        val cardView_Main_DownloadImagem = findViewById<CardView>(R.id.cardView_Main_DownloadImagem)
        cardView_Main_DownloadImagem.setOnClickListener(this)

        val cardView_Main_UploadImagem = findViewById<CardView>(R.id.cardView_Main_UploadImagem)
        cardView_Main_UploadImagem.setOnClickListener(this)

        val cardView_Main_LerDados = findViewById<CardView>(R.id.cardView_Main_LerDados)
        cardView_Main_LerDados.setOnClickListener(this)

        val cardView_Main_GravarAlterarLerDados = findViewById<CardView>(R.id.cardView_Main_GravarAlterarLerDados)
        cardView_Main_GravarAlterarLerDados.setOnClickListener(this)

        val cardView_Main_Categorias = findViewById<CardView>(R.id.cardView_Main_Categorias)
        cardView_Main_Categorias.setOnClickListener(this)

        val cardView_Main_Deslogar = findViewById<CardView>(R.id.cardView_Main_Deslogar)
        cardView_Main_Deslogar.setOnClickListener(this)

        permissao()
        ouvinteAutenticacao()

    }


    // Permisão
    fun permissao(){
        val permissoes = arrayOf<String>(
            android.Manifest.permission.WRITE_EXTERNAL_STORAGE,android.Manifest.permission.READ_EXTERNAL_STORAGE,android.Manifest.permission.CAMERA
        )

        Util.permissao(this,100, permissoes )
    }

    // Ouvinte autenticação
    fun ouvinteAutenticacao(){
        val auth = Firebase.auth
        auth.addAuthStateListener { authAtual ->
            if (authAtual.currentUser != null){
                Util.exibirToast(baseContext,"Usuário Logado")
            }else{
                Util.exibirToast(baseContext,"Deslogado")
            }
        }
    }

    // Ações de clique
    override fun onClick(p0: View?) {
        val cardView_Main_Deslogar = findViewById<CardView>(R.id.cardView_Main_Deslogar)
        val cardView_Main_DownloadImagem = findViewById<CardView>(R.id.cardView_Main_DownloadImagem)
        val cardView_Main_UploadImagem = findViewById<CardView>(R.id.cardView_Main_UploadImagem)
        val cardView_Main_LerDados = findViewById<CardView>(R.id.cardView_Main_LerDados)
        val cardView_Main_GravarAlterarLerDados = findViewById<CardView>(R.id.cardView_Main_GravarAlterarLerDados)
        val cardView_Main_Categorias = findViewById<CardView>(R.id.cardView_Main_Categorias)

        when(p0?.id){

            cardView_Main_DownloadImagem.id ->{
                Util.exibirToast(baseContext,"cardView_Main_DownloadImagem")
            }

            cardView_Main_UploadImagem.id ->{
                Util.exibirToast(baseContext,"cardView_Main_UploadImagem")
            }

            cardView_Main_LerDados.id ->{
                Util.exibirToast(baseContext,"cardView_Main_LerDados")
            }

            cardView_Main_GravarAlterarLerDados.id ->{
                Util.exibirToast(baseContext,"cardView_Main_GravarAlterarLerDados")
            }

            cardView_Main_Categorias.id ->{
                Util.exibirToast(baseContext,"cardView_Main_Categorias")
            }

            cardView_Main_Deslogar.id ->{
                finish()
                val auth = Firebase.auth
                auth.signOut()
                startActivity(Intent(this,AberturaActivity::class.java))
            }
            else -> false
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        for(result in grantResults){
            if (result == PackageManager.PERMISSION_DENIED){

                Util.exibirToast(baseContext,"Aceite as permisões para funcionar o aplicativo")
                finish()
                break
            }

        }

    }



}