package com.anydigital.inventorycontrolv1

import android.content.ContentValues.TAG
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import com.anydigital.inventorycontrolv1.util.DialogProgress
import com.anydigital.inventorycontrolv1.util.Util
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class AberturaActivity : AppCompatActivity(), View.OnClickListener {


    var auth: FirebaseAuth? = null
// ...
// Initialize Firebase Auth
    //auth = Firebase.auth


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_abertura)

        val buttonLogin = findViewById<Button>(R.id.button_login)

        buttonLogin.setOnClickListener(this)

        // Initialize Firebase Auth
        auth = Firebase.auth

        val user = auth?.currentUser

        if (user != null){
            finish() // Finaliza a tela de login ao retornar a ela
            val intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
        }

    }

    override fun onClick(p0: View?) {
        val buttonLogin = findViewById<Button>(R.id.button_login)
        when (p0?.id) {
            buttonLogin.id -> {
                buttonLogin()
            }
            else -> false
        }
    }

    fun buttonLogin() {
        val editText_Login_Email = findViewById<EditText>(R.id.editText_Login_Email)
        val email = editText_Login_Email.text.toString()

        val editText_Login_Senha = findViewById<EditText>(R.id.editText_Login_Senha)
        val password = editText_Login_Senha.text.toString()

        //Util.exibirToast(this, "email: $password" + "Senha:" + password)


        if (!email.trim().equals("") && !password.trim().equals("")) {
            if (Util.statusInternet(this)) {
                //Util.exibirToast(this, "Você está conectado")
                login(email, password)
            } else {
                Util.exibirToast(this, "Você está sem conexão com a Internet")
            }
            //Util.exibirToast(this,"Você inseriu todos os dados ")
        } else {
            Util.exibirToast(this, "Preencha todos os dados")
        }
    }

    fun login(email: String, password: String) {
        val dialogProgress = DialogProgress()
        dialogProgress.show(supportFragmentManager,"1")

        auth?.signInWithEmailAndPassword(email, password)
            ?.addOnCompleteListener(this) { task ->
                dialogProgress.dismiss()

                if (task.isSuccessful) {

                    //Util.exibirToast(baseContext, "Login realizado com sucesso")
                    finish() // Finaliza a tela de login ao retornar a ela
                    val intent = Intent(this,MainActivity::class.java)
                    startActivity(intent)
                } else {

                    //Util.exibirToast(baseContext, "Falha de Login ${task.exception.toString()}")

                    val erro = task.exception.toString()
                    errosFirebase(erro)
                    Log.i("signInWithEmailAndPassword", task.exception.toString())
                }
            }


        /*
        auth?.signInWithEmailAndPassword(email, password)
            ?.addOnSuccessListener {
                Util.exibirToast(baseContext, "Login realizado com sucesso")
            }?.addOnFailureListener{error ->
                val erro = error.message.toString()
                errosFirebase(erro)
                Log.i("signInWithEmailAndPassword", error.message.toString())
            }
        */

    }

    fun errosFirebase(erro: String) {
        if (erro.contains("The password is invalid")) {
            Util.exibirToast(baseContext, "A senha é inválida ou não foi informada")
        } else if (erro.contains("There is no user record corresponding to this identifier")) {
            Util.exibirToast(baseContext, "Esse email não é válido")
        } else {
            Util.exibirToast(baseContext, "Email ou senha incorreto")
        }
    }
}


